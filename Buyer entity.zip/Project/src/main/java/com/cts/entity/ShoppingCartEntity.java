package com.cts.entity;

import java.util.List;

import javax.persistence.*;


@Entity
public class ShoppingCartEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int cartId;
	private float price;
	private String description;
	
	
	
	  @OneToMany(cascade=CascadeType.ALL,mappedBy="shoppingCart")
	  private List<ItemsEntity> itemsEntity;
	    
	  public List<ItemsEntity> getItemsEntity()
	  {
		  return itemsEntity; 
		  } 
	  public void setItemsEntity(List<ItemsEntity> itemsEntity)
	  {
		  this.itemsEntity = itemsEntity; 
		  }
	 
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public ShoppingCartEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShoppingCartEntity(int cartId, float price, String description) {
		super();
		this.cartId = cartId;
		this.price = price;
		this.description = description;
	}
	@Override
	public String toString() {
		return "ShoppingCartEntity [cartId=" + cartId + ", price=" + price + ", description=" + description + "]";
	}
	
	
	
	
	
	

}
