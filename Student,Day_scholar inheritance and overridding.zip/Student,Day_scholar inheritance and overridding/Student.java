/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance and overridding, student example Student,DayScholar,Residential,test2 */
package com.cts.questions;

public class Student {
	
	public void walk() {
		System.out.println("students walk ");
	}
	
	public void study() {
		System.out.println("students study at library");
	}
	
	public void breakfast() {
		System.out.println("have food at classroom");
	}

}
