import { Component } from '@angular/core';
import { User } from './user';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
isValid = true;
count=0;
ids = [1,2,3,4];
title = 'app';

	users = [
      new User('Mahesh', 20,'mah@gmail.com'),
      new User('Krishna', 22,'kri@gmail.com'),
      new User('Narendra', 31,'nar@gmail.com')
    ];
change(){
  this.count=this.count+1;
/*  if(this.isValid)
    {
      this.isValid=false;

    }
    else{
      this.isValid=true;
    }*/
}
    
 }


