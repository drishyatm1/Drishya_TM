export class User{
    public name:string;
    public age:number;
    public email:string;

    constructor(name:string,
        age:number,email:string){
            this.name=name;
            this.age=age;
            this.email=email;
        }
}