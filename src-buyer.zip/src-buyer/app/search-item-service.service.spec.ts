import { TestBed } from '@angular/core/testing';

import { SearchItemServiceService } from './search-item-service.service';

describe('SearchItemServiceService', () => {
  let service: SearchItemServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchItemServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
