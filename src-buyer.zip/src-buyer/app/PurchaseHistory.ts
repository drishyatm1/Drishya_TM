export class PurchaseHistory{
    purchaseHistoryId:number;
    numberOfItems: number;
    buyerId: number;
}