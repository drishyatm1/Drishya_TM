import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { SearchItemComponent } from './search-item/search-item.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { BuyerAfterLoginComponent } from './buyer-after-login/buyer-after-login.component';
import { SignupComponent } from './signup/signup.component';
import { TransactionComponent } from './transaction/transaction.component';
import { TokenInterceptor } from './interceptor';
import { SearchItemServiceService } from './search-item-service.service';
import { SigninComponent } from './signin/signin.component';
import { LogoutComponent } from './logout/logout.component';
import { TransactionSuccessComponent } from './transaction-success/transaction-success.component';
import { HomeComponent } from './home/home.component';



@NgModule({
  declarations: [
    AppComponent,
    SearchItemComponent,
    DisplayCartComponent,
    MainMenuComponent,
    BuyerAfterLoginComponent,
    SignupComponent,
    SigninComponent,
    TransactionComponent,
    LogoutComponent,
    TransactionSuccessComponent,
    HomeComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
