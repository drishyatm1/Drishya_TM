/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Derived class */
package com.cts.day2inheritance;

public class Test_employee {
	
	public static void main(String args[]) {
		Admin ob1=new Admin(101,"Ravi","Admin","CTS");
		 ob1.work();
	}

}

