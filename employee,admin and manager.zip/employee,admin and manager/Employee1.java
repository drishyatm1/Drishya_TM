/* Author: Drishya TM 
 * Date: 08/01/2020
 * Program : inheritance, Base class */
package com.cts.day2inheritance;

public class Employee1 {
	public int empId=101;
	public String empName="ravi";
	


}
