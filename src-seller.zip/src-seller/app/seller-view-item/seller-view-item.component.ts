import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-seller-view-item',
  templateUrl: './seller-view-item.component.html',
  styleUrls: ['./seller-view-item.component.css']
})
export class SellerViewItemComponent implements OnInit {

  constructor(private viewItem:SellerServiceService) { }
  
  displayItem:Item[];
  item: Item;
  sid:string=localStorage.getItem("id");
  ngOnInit(): void {
    this.viewItem.viewItem(this.sid)
    .subscribe(displayItem => this.displayItem= displayItem)
    console.log(this.displayItem)
  }

  deleteItem(itemId:number){
    console.log(this.sid);
    this.viewItem.deleteItem(this.sid,itemId)
    .subscribe(()=>{alert("Product deleted successfully .")});

  }

  increase(item,iId:number){
    item.stockNumber+=1;

    this.viewItem.updateItem1(iId,item,this.sid).subscribe(newView => this.item=newView);


  }
}
