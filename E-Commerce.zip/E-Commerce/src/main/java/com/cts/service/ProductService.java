package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ProductDao;
import com.cts.model.Product;

@Service
public class ProductService {

	@Autowired
	ProductDao pDao;

	public Product getProductById(int productid) {
		Product product=pDao.getProductById(productid);
		
		return product;
	}

	public int updateProdModel(Product product)
	{
		return pDao.updateProduct(product);
	}

	public int addProdModel(Product product) {
		return pDao.addProduct(product);
		
	}

	public int deleteProdModel(int productId)
	{
		return pDao.deleteProduct(productId);
	}
}
