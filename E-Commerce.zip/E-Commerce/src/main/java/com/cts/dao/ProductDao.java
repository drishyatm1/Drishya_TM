package com.cts.dao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.model.Product;

@Repository
public class ProductDao extends JdbcDaoSupport {
	
	
	public int addProduct(Product product){
		int addStatus=getJdbcTemplate().update("INSERT INTO product values(?,?,?,?)",new Object[]{product.getProductId(),product.getProductName(),product.getProquctQuantity(),product.getProductPrice()});
		System.out.println(addStatus);
		return product.getProductId();
		
			}
	
	public int deleteProduct(int productId) {
		int deleteStatus=getJdbcTemplate().update("DELETE from product where productId=?",new Object[]{productId});
		System.out.println(deleteStatus);
		return deleteStatus;
		
	}
	
	public int updateProduct(Product product) {
		int updateStatus=getJdbcTemplate().update("UPDATE product set productName=? , proquctQuantity=? , productPrice=? where productId=?",new Object[]{product.getProductId(),product.getProductName(),product.getProquctQuantity(),product.getProductPrice()});
		return updateStatus;
		
	}
	
	
	public Product getProductById(int productId)
	{
	Product product=getJdbcTemplate().queryForObject("SELECT * FROM product WHERE productId = ?",
	    new Object[] { productId }, new BeanPropertyRowMapper<Product>(Product.class));
	return product;

	}


	

}
