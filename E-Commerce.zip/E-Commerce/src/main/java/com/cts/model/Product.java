package com.cts.model;

import org.springframework.stereotype.Component;

@Component
public class Product {

	private int productId;
	private String productName;
	private int proquctQuantity;
	private float productPrice;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProquctQuantity() {
		return proquctQuantity;
	}
	public void setProquctQuantity(int proquctQuantity) {
		this.proquctQuantity = proquctQuantity;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	
	public Product() {
		
	}
}
