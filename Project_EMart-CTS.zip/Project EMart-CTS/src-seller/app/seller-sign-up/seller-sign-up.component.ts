import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Seller } from '../Seller';
import { SellerServiceService } from '../seller-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-sign-up',
  templateUrl: './seller-sign-up.component.html',
  styleUrls: ['./seller-sign-up.component.css']
})
export class SellerSignUpComponent implements OnInit {

  constructor(private sellerservice:SellerServiceService,private router: Router) { }

  seller: Seller=new Seller();
  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    console.log(this.seller);
    this.sellerservice.addSeller(this.seller)
    .subscribe(seller=>{alert("your details are saved successfully .")})
    console.log(this.seller);
    this.router.navigate(['signin']);
  }

}
