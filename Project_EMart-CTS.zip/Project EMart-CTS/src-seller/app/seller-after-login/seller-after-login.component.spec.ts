import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerAfterLoginComponent } from './seller-after-login.component';

describe('SellerAfterLoginComponent', () => {
  let component: SellerAfterLoginComponent;
  let fixture: ComponentFixture<SellerAfterLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerAfterLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAfterLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
