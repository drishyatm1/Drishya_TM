package com.cts.SellerService;

import java.util.List;

import com.cts.SellerModel.SellerEntity;

public interface ISellerService {

	List<SellerEntity> getAllSeller();

	SellerEntity addSeller(SellerEntity seller);

}
