package com.cts.SellerService;

import java.util.List;

import com.cts.SellerModel.CategoryEntity;
import com.cts.SellerModel.SubCategoryEntity;

public interface ISubCategoryService {

	List<SubCategoryEntity> getAllSubCategory();

	

}
