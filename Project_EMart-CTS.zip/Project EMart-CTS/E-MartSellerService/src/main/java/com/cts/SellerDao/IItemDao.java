package com.cts.SellerDao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.SellerModel.ItemEntity;

@Repository
public interface IItemDao extends JpaRepository<ItemEntity, Integer>  {

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM item WHERE item_id = :pId AND seller_seller_id=:sId ",nativeQuery = true)
	void deleteItem(@Param("sId") Integer sellerId , @Param("pId") Integer itemId);

	@Query(value = "SELECT * FROM item i WHERE i.seller_seller_id = :sellerId",nativeQuery = true)
	List<ItemEntity> viewItem(@Param("sellerId")Integer sellerId);

	//part of update
	@Query(value = "SELECT * FROM item  WHERE item.seller_seller_id = :sid AND item.item_id= :pid",nativeQuery = true)
	ItemEntity getItemBy(@Param("sid")Integer sellerId, @Param("pid") Integer itemId);

	
	//matching item by name
	@Query(value="SELECT * FROM item WHERE item_name like :name%",nativeQuery = true)
	List<ItemEntity> getMatchingItem(@Param("name") String name);

	

}
