package com.cts.SellerController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SellerModel.CategoryEntity;
import com.cts.SellerService.ICategoryService;


@RestController
public class CategoryController {

	@Autowired
	private ICategoryService catService;
	
	@GetMapping("/getAllCategory")
	public List<CategoryEntity> getAll(){
		
		return catService.getAllCategory();
	}
}
