package com.cts.SellerService;

import java.util.List;

import com.cts.SellerModel.CategoryEntity;

public interface ICategoryService {

	List<CategoryEntity> getAllCategory();

}
