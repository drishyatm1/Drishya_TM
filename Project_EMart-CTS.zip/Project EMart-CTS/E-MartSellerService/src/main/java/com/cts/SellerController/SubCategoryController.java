package com.cts.SellerController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SellerModel.SubCategoryEntity;
import com.cts.SellerService.ISubCategoryService;


@RestController
public class SubCategoryController {

	@Autowired
	private ISubCategoryService subcatService;
	
	@GetMapping("/getAllSubCategory")
	public List<SubCategoryEntity> getAllSubCategory(){
		
		return subcatService.getAllSubCategory();
	}
}
