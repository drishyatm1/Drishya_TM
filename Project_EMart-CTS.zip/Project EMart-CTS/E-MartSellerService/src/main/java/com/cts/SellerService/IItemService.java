package com.cts.SellerService;

import java.util.List;

import com.cts.SellerModel.ItemEntity;

public interface IItemService {

	String addItem(int sid, ItemEntity item);

	void deleteBySeller(Integer sId, Integer pId);

	List<ItemEntity> viewItem(Integer sellerId);

	String updateItem(int sid, int pid, ItemEntity item);

	List<ItemEntity> getMatchingItem(String name);



}
