package com.cts.SellerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SellerDao.ICategoryDao;
import com.cts.SellerModel.CategoryEntity;
import com.cts.SellerModel.SubCategoryEntity;

@Service
public class CategoryService implements ICategoryService{

	
	@Autowired
	private ICategoryDao catDao;
	
	@Override
	public List<CategoryEntity> getAllCategory() {
		
		return catDao.findAll();
	}

	

}
