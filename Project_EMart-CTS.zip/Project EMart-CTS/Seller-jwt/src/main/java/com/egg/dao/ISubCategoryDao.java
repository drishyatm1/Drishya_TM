package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.SubCategoryEntity;





@Repository
public interface ISubCategoryDao extends JpaRepository<SubCategoryEntity, Integer>{

}
