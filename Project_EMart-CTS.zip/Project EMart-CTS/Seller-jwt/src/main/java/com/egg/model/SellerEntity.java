package com.egg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="seller")
public class SellerEntity {
	
		@Id
		@GeneratedValue(strategy= GenerationType.IDENTITY)
		@Column(name="seller_id")
		private int sellerId;
		private String username;
		private String password;
		@Column(name="company_name")
		private String companyName;
		@Column(name="gstin")
		private long GSTIN;
		@Column(name="company_description")
		private String companyDescription;
		@Column(name="address")
		private String PostalAddress;
		private String website;
		@Column(name="email_id")
		private String emailID;
		@Column(name="contact_no")
		private long contactNo;
		
		
		public int getSellerId() {
			return sellerId;
		}
		public void setSellerId(int sellerId) {
			this.sellerId = sellerId;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getCompanyName() {
			return companyName;
		}
		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}
		public long getGSTIN() {
			return GSTIN;
		}
		public void setGSTIN(long gSTIN) {
			GSTIN = gSTIN;
		}
		public String getCompanyDescription() {
			return companyDescription;
		}
		public void setCompanyDescription(String companyDescription) {
			this.companyDescription = companyDescription;
		}
		public String getPostalAddress() {
			return PostalAddress;
		}
		public void setPostalAddress(String postalAddress) {
			PostalAddress = postalAddress;
		}
		public String getWebsite() {
			return website;
		}
		public void setWebsite(String website) {
			this.website = website;
		}
		public String getEmailID() {
			return emailID;
		}
		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}
		public long getContactNo() {
			return contactNo;
		}
		public void setContactNo(long contactNo) {
			this.contactNo = contactNo;
		}
	
		
		public SellerEntity() {
			super();
			
		}
		public SellerEntity(int sellerId, String username, String password, String companyName, long gSTIN,
				String companyDescription, String postalAddress, String website, String emailID, long contactNo) {
			super();
			this.sellerId = sellerId;
			this.username = username;
			this.password = password;
			this.companyName = companyName;
			this.GSTIN = gSTIN;
			this.companyDescription = companyDescription;
			this.PostalAddress = postalAddress;
			this.website = website;
			this.emailID = emailID;
			this.contactNo = contactNo;
		}
		@Override
		public String toString() {
			return "SellerEntity [sellerId=" + sellerId + ", username=" + username + ", password=" + password
					+ ", companyName=" + companyName + ", GSTIN=" + GSTIN + ", companyDescription=" + companyDescription
					+ ", PostalAddress=" + PostalAddress + ", website=" + website + ", emailID=" + emailID
					+ ", contactNo=" + contactNo + "]";
		}
		
		
		
		
		
		
		

}
