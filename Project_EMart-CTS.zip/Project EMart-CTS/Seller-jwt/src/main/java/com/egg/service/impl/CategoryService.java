package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.ICategoryDao;
import com.egg.model.CategoryEntity;
import com.egg.model.SubCategoryEntity;
import com.egg.service.ICategoryService;

@Service
public class CategoryService implements ICategoryService{

	
	@Autowired
	private ICategoryDao catDao;
	
	@Override
	public List<CategoryEntity> getAllCategory() {
		
		return catDao.findAll();
	}

	

}
