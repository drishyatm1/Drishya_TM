import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaction-success',
  templateUrl: './transaction-success.component.html',
  styleUrls: ['./transaction-success.component.css']
})
export class TransactionSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
