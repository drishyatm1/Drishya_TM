export class Buyer{
    buyerId:number;
    buyerUsername: String;
    buyerPassword: String;
    buyerEmailid: String;
    buyerMobile: number;
}