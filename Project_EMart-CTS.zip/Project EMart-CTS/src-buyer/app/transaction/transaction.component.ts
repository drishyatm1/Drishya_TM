import { Component, OnInit } from '@angular/core';
import { Transaction } from '../Transaction';
import { SearchItemServiceService } from '../search-item-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  transaction: Transaction= new Transaction();
  
  
  constructor(private transactions :SearchItemServiceService,private router:Router) { }

  ngOnInit(): void {
  }
  bid:String=localStorage.getItem("id");
  pay(){
    console.log(this.transaction);
    this.transactions.checkOut(this.transaction,this.bid)
    .subscribe(cart => {alert("You have ordered all items")});
    this.router.navigate(['success']);
  }
  
}
