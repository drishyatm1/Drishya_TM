package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;
import com.cts.model.TransactionEntity;
import com.cts.service.ICartService;




@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cart")
public class CartController {
	@Autowired
	private ICartService cartService;
	
		
	@GetMapping("/getAll/CartItem")
	public List<ShoppingCartEntity> getAll(){
		
		return cartService.getAllCart();
	}
		

	@GetMapping(value = "getCartItem/ByBuyerId/{bid}")
	public List<ShoppingCartEntity> getAllCartItems(@PathVariable("bid")Integer buyerId) {
		return cartService.getAllCartItems(buyerId);
		}
	
	
	@PostMapping("/addToCart/ById/{id}")
	public String addCart(@PathVariable("id") int bid, @RequestBody ShoppingCartEntity cItem) {
		
		return cartService.addCart(bid,cItem);
	}
	
	
	//done by buyer based on cart id
	@DeleteMapping("deleteById/{cid}")
	public void deleteById(@PathVariable("cid") Integer bId) {
		
		cartService.deleteById(bId);
		
	}
	
	//to empty the cart by buyer
	@DeleteMapping(value = "deleteAll/ByBid/{bid}")
	public void emptyCart(@PathVariable("bid") Integer buyerId) {
		cartService.emptyCart(buyerId);
	}
	
		
	@PostMapping("/updatecart/{cid}")
	public String updateCart(@PathVariable("cid") int cid,@RequestBody ShoppingCartEntity sCart)
	{
		return cartService.updateCart(cid,sCart);
	}

	@PostMapping("/checkout/{bid}")
	public String checkOut(@RequestBody TransactionEntity transaction,@PathVariable("bid") int buyerid)
	{
		return cartService.checkOut(transaction,buyerid);
	}
	
	
}
