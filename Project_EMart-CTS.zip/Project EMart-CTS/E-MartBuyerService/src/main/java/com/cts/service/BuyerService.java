package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.IBuyerDao;
import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;

@Service
public class BuyerService implements IBuyerService {

	
	@Autowired
	private IBuyerDao dao;
	
	
	@Override
	public List<BuyerEntity> getAllPersons() {
		
		return dao.findAll();
	}

	@Override
	public BuyerEntity add(BuyerEntity buyer) {
		
		return dao.save(buyer);
	}

	

	/*
	 * @Override public Optional<ShoppingCartEntity> getbyBuyerId(int pid) {
	 * 
	 * return dao.findById(pid); }
	 */
	

	
}
