package com.cts.service;

import java.util.List;

import com.cts.model.ItemsEntity;

public interface IItemService {

	List<ItemsEntity> getMatchingItem(String name);

}
