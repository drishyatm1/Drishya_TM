package com.egg.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.IBuyerDao;
import com.egg.model.BuyerEntity;
import com.egg.model.ShoppingCartEntity;
import com.egg.service.IBuyerService;

@Service(value = "userService")
public class BuyerService implements IBuyerService, UserDetailsService {

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	@Autowired
	private IBuyerDao dao;
	
	
	@Override
	public List<BuyerEntity> getAllPersons() {
		
		return dao.findAll();
	}

	@Override
	public BuyerEntity add(BuyerEntity buyer) {
		buyer.setBuyerPassword(bcryptEncoder.encode(buyer.getBuyerPassword()));
		return dao.save(buyer);
	}

	@Override
	public BuyerEntity findOne(String username) {
		
		return dao.findByBuyerUsername(username);
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
		}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerEntity buyer = dao.findByBuyerUsername(username);
		if(buyer == null){
		throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getBuyerUsername(), buyer.getBuyerPassword(), getAuthority());
		
	}

	

	
	

	
}
