package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.BuyerEntity;
import com.egg.model.ShoppingCartEntity;
import com.egg.service.IBuyerService;





@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/buyer")
public class BuyerController {
	
	@Autowired
	private IBuyerService service;
	
	@GetMapping("/getAll")
	public List<BuyerEntity> getAll(){
		
		return service.getAllPersons();
	}
	
	
	@RequestMapping(value="/addBuyer", method= RequestMethod.POST, produces="application/json")
	public BuyerEntity addBuyer(@RequestBody BuyerEntity person) {
		
		return service.add(person);
	}
	
	
	
	

}
