package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.PurchaseHistoryEntity;



public interface IPurchaseHistoryDao extends JpaRepository<PurchaseHistoryEntity, Integer> {

}
