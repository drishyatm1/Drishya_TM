package com.egg.service;

import java.util.List;

import com.egg.model.ItemsEntity;

public interface IItemService {

	List<ItemsEntity> getMatchingItem(String name);

}
