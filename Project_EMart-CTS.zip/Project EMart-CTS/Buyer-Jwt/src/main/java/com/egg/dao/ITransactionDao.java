package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.TransactionEntity;



public interface ITransactionDao extends JpaRepository<TransactionEntity, Integer>{

}
