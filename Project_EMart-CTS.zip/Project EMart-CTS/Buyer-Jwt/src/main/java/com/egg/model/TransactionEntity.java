package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class TransactionEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	public int transactionId;
	//public int userId;
	//public int sellerId;
	public String transactionType;
	

	@ManyToOne
	private BuyerEntity buyer;
	
	

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public BuyerEntity getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerEntity buyer) {
		this.buyer = buyer;
	}


	

	public TransactionEntity(int id, int userId, int sellerId, String transactionType, String remarks) {
		super();
		transactionId = id;
		//this.userId = userId;
		//this.sellerId = sellerId;
		this.transactionType = transactionType;
		//this.remarks = remarks;
	}

	public TransactionEntity() {
		super();
		System.out.println("transaction obj created");
	}

	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType + ", buyer="
				+ buyer + "]";
	}

	

	


	
}
