package com.egg.service;

import java.util.List;

import com.egg.model.ItemEntity;

public interface IItemService {

	String addItem(int sid, ItemEntity item);

	void deleteBySeller(Integer sId, Integer pId);

	List<ItemEntity> viewItem(Integer sellerId);

	String updateItem(int sid, int pid, ItemEntity item);

	List<ItemEntity> getMatchingItem(String name);



}
