package com.cts.SellerController;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SellerModel.ItemEntity;
import com.cts.SellerService.IItemService;


@RestController
public class ItemController {
	
	@Autowired
	private IItemService itemeService;
	
	
	@PostMapping("/addItem/BySellerId/{id}")
	public String addCart(@PathVariable("id") int sid, @RequestBody ItemEntity item) {
		
		return itemeService.addItem(sid,item);
	}
	
	@DeleteMapping("deleteById/{sid}/{pid}")
	public void deleteById(@PathVariable("sid") Integer sId, @PathVariable("cid") Integer pId) {
		
		itemeService.deleteBySeller(sId,pId);
		
	}
	

}
