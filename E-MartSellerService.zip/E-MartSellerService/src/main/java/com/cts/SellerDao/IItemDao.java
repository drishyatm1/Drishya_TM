package com.cts.SellerDao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.SellerModel.ItemEntity;

@Repository
public interface IItemDao extends JpaRepository<ItemEntity, Integer>  {

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM item WHERE item_id = :pId AND seller_seller_id=:sId ",nativeQuery = true)
	void deleteItem(@Param("sId") Integer sellerId , @Param("pId") Integer itemId);

}
