package com.cts.SellerModel;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="subcategory")
public class SubCategoryEntity {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int subcategoryId;
	private String subcategoryName;
	private String briefDetails;
	
	@ManyToOne
	private CategoryEntity category;
	
	
	
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public SubCategoryEntity(int subcategoryId, String subcategoryName, String briefDetails) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.briefDetails = briefDetails;
	}
	public SubCategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", briefDetails=" + briefDetails + "]";
	}
	
	
}
