package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.service.IPersonService;

@RestController
public class MyRestController {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("getAll")
	public List<Person> getAll(){
		
		return service.getAllPersons();
	}
	
	
	@RequestMapping("getById/{eid}")
	public Person getbyId(@PathVariable("eid") int pid) {
		
		Optional<Person> p=service.getPersonById(pid);
		Person pObj=null;
		if(p.isPresent()){
		 pObj=p.get();	
		}		
		return pObj;
	}
	@RequestMapping("getByName/{ename}")
	public Person getbyName(@PathVariable("ename") String name) {
		return service.getPersonByName(name);
	}	
	@RequestMapping("getBoth/{ename}/{addr}")
	public Person getbyName(@PathVariable("ename") String name,@PathVariable("addr") String addr) {
		return service.findUsingNameAddr(name, addr);
	}	
	
	@RequestMapping(value = "deleteById/{pid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("pid") Integer personId) {
		
		service.deleteById(personId);
	}
	
	
	
	
	@RequestMapping(value="/add", method= RequestMethod.POST, produces="application/json")
	public String addPerson(@RequestBody Person person) {
		
		return service.add(person);
	}
	
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Person updatePerson(@RequestBody Person person) {
		
		return service.update(person);
	}
	
}





