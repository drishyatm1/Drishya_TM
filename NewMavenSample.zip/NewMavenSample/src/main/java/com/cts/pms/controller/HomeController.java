package com.cts.pms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	@RequestMapping("/")
	public String getForm(Model m) {
		Product product=new Product();
		m.addAttribute("prod", product);
		
		
		return "index";
		
	}
	
	@RequestMapping("process.do")
	public String getResult(@RequestParam("pName") String name, @RequestParam("quantity") int quantity, @RequestParam("price") float price, Model md) {
		md.addAttribute("productName", name);
		md.addAttribute("productQuantity", quantity);
		md.addAttribute("productPrice", price);
		return "result";
	}

}
