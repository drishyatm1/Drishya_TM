package com.cts.pms.controller;

public class Product {

	private int id;
	private String pName;
	private int quantity;
	private float price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public Product() {
		  
	}
	
	public Product(String name,int quantity,float price) {
		this.pName=name;
		this.price=price;
		this.quantity=quantity;
		
	}
	
	
}
