package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.egg.model.ItemsEntity;

public interface IItemDao extends JpaRepository<ItemsEntity, Integer> {
	
	//matching item by name
			@Query(value="SELECT * FROM item WHERE item_name like :name%",nativeQuery = true)
			List<ItemsEntity> getMatchingItem(@Param("name") String name);


}
