package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.IItemDao;
import com.egg.model.ItemsEntity;
import com.egg.service.IItemService;

@Service
public class ItemServices implements IItemService {

	
	@Autowired
	private IItemDao itemsDao;
	
	@Override
	public List<ItemsEntity> getMatchingItem(String name) {
		return itemsDao.getMatchingItem(name);
	}

}
