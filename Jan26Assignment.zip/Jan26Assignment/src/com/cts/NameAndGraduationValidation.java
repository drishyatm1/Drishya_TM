package com.cts;

import java.util.Scanner;

public class NameAndGraduationValidation {
	
	public static void main(String args[]) {
		String name;
		int graduationYear=0;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter student name");
		while(!scan.hasNext("[A-Za-z.!@#$%^&*]+"))
		{
			System.out.println("Please enter a valid name");
			scan.next();
		}
		
		name=scan.next();
		

		int c = 0;
		do {
			
			
		System.out.println("Enter your year of graduation:");
		
		try 
        { 
           
			graduationYear =Integer.parseInt(scan.next());
            c=0;
        }  
        catch (NumberFormatException e)  
        { 
            
        	System.out.println("Please enter a valid year"); 
            c++;
            
        } 
		}while(c!=0);
		System.out.println("My name is "+name+" and I will graduate in "+graduationYear+".");

	}
}