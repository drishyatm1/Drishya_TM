package com.cts;

import java.util.Scanner;

public class NameAndGraduation {
	
	
	
	public static void main(String args[]) {
		String name;
		int graduationYear;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter student name");
		name=scan.next();
		
		System.out.println("Enter your year of graduation");
		graduationYear=Integer.parseInt(scan.next());
		
		System.out.println("My name is "+name+" and I will graduate in "+graduationYear+".");

	}

}
